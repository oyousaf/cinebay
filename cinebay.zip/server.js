import express from "express";
import axios from "axios";
import dotenv from "dotenv";
import cors from "cors";

dotenv.config();

const app = express();
const PORT = 5000;

app.use(cors());

// 🔥 FIXED: wildcard route syntax
app.get("/api/tmdb/*", async (req, res) => {
  const TMDB_KEY = process.env.TMDB_KEY;
  if (!TMDB_KEY) {
    return res.status(500).json({ error: "Missing TMDB API key" });
  }

  // Extract TMDB path and query
  const tmdbPath = req.params[0]; // matched by '*'
  const query = req.url.split("?")[1] ?? "";
  const separator = query ? "&" : "";
  const tmdbUrl = `https://api.themoviedb.org/3/${tmdbPath}?${query}${separator}api_key=${TMDB_KEY}`;

  try {
    const { data } = await axios.get(tmdbUrl);
    res.status(200).json(data);
  } catch (err) {
    console.error("❌ TMDB Proxy Error:", err.message);
    res.status(500).json({ error: "TMDB fetch failed" });
  }
});

// ✅ Listen on IPv4 for localhost proxying
app.listen(PORT, "0.0.0.0", () => {
  console.log(`✅ Server running on http://localhost:${PORT}`);
});
