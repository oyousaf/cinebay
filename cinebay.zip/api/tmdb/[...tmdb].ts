import { VercelRequest, VercelResponse } from '@vercel/node';
import axios from 'axios';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  const TMDB_KEY = process.env.TMDB_KEY;
  if (!TMDB_KEY) return res.status(500).json({ error: "Missing TMDB API key" });

  const { url = '' } = req;
  const pathMatch = url.match(/\/api\/tmdb\/(.*)/);

  if (!pathMatch) {
    return res.status(400).json({ error: "Missing TMDB path" });
  }

  const tmdbPath = pathMatch[1];
  const query = req.url?.split('?')[1] ?? '';
  const separator = query ? '&' : '';
  const tmdbUrl = `https://api.themoviedb.org/3/${tmdbPath}?${query}${separator}api_key=${TMDB_KEY}`;

  try {
    const { data } = await axios.get(tmdbUrl);
    res.status(200).json(data);
  } catch (err: any) {
    console.error("❌ Serverless TMDB Proxy Error:", err.message);
    res.status(500).json({ error: "TMDB fetch failed" });
  }
}
